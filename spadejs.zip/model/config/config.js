const { Sequelize } = require("sequelize");

const sequelize = new Sequelize(
  "shikshah_laravel",
  "shikshah_spade",
  "I#R0.gbGyGUQ",
  {
    host: "localhost",
    dialect: "mysql"
  }
);

module.exports = sequelize;
