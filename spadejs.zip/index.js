const sequelize = require("./model/config/config");

const relations = require("./model/config/relations");
const { makeMatch, lowCardGameSocket } = require("./controller/low_card");
// const  seedUser  = require("./seeder/user_seeder")();

const port = 8000;

const app = require("express")();
const http = require("http").Server(app);
const io = require("socket.io")(http);

const testSocketNamespace = io.of("/low-card-game");
lowCardGameSocket(testSocketNamespace)

sequelize.authenticate().then(() => {
  console.log("Connection has been established");
  sequelize.sync({ force: true });
});

app.get("/", (req, res) => {
  res.send("Hello World!");
});
 
app.get("/make-match", makeMatch);

http.listen(port, () => {
  console.log(`http://localhost:${port}/makeMatch`);
  console.log(`Example app listening on port ${port}`);
});
